# DigiHinet Telegram Bot

بسته کامل برای مخزن جدید؛ تمام فایل‌ها آماده‌اند.

## آپلود در مخزن جدید

۱. فایل ZIP را Extract All کنید. خود ZIP را در GitHub آپلود نکنید.
۲. یک مخزن جدید Public بسازید و Add a README را روشن کنید.
۳. در ویندوز View → Show → Hidden items را روشن کنید تا پوشه .github دیده شود.
۴. در GitHub بزنید Add file → Upload files.
۵. تمام محتویات پوشه استخراج‌شده، شامل خود پوشه .github، را با هم داخل صفحه بکشید. از انتخاب فایل‌های داخل پوشه‌ها به صورت جداگانه خودداری کنید تا مسیرها حفظ شوند.
۶. Commit changes را بزنید.
۷. در مخزن پوشه .github را باز کنید؛ فایل workflows/publish.yml باید داخل آن باشد. فایل bot.py باید در ریشه مخزن باشد.

فایل زمان‌بندی از ابتدا داخل مسیر درست بسته قرار دارد؛ نام هیچ فایلی را تغییر ندهید.

## اتصال و راه‌اندازی

در @BotFather با /newbot یک بات جدید بسازید. بات را در کانال اصلی و یک کانال عمومی آزمایشی جدا مدیر کنید و مجوز Post Messages بدهید.

Settings → Secrets and variables → Actions → Secrets → New repository secret:

- TELEGRAM_BOT_TOKEN: توکن بات جدید
- TELEGRAM_CHANNEL_ID: @digihinet
- TELEGRAM_TEST_CHANNEL_ID: آیدی کانال آزمایشی با @

Settings → Actions → General → Workflow permissions → Read and write permissions → Save.

Actions → DigiHinet Channel → Run workflow:

- ابتدا mode=preview و kind=card: فقط پیش‌نمایش؛ دانلود خروجی از Artifacts.
- سپس mode=test و kind=card: ارسال واقعی به کانال آزمایشی.

برای روشن‌کردن انتشار اصلی:

Settings → Secrets and variables → Actions → Variables → New repository variable:

- Name: ENABLE_POSTING
- Value: true

برنامه روزانه حدود ساعت ۱۸:۱۷ تهران اجرا می‌شود؛ GitHub ممکن است تأخیر داشته باشد. برای اولین انتشار فوری، Run workflow → mode=publish → kind=auto. این حالت واقعاً به کانال اصلی پیام می‌فرستد. برای توقف، ENABLE_POSTING را false کنید.

راهنمای کامل محتوا، رفع خطا و pending در GUIDE.md است. این نسخه ۲۴ متن آموزشی و ۸ کارت دارد، مقاله منتشرشده سایت را دریافت می‌کند و یک نمونه‌کار اولیه رونکا با شناسایی ویدیوی صفحه پروژه دارد. تولید نامحدود AI ندارد و برای ادامه، بانک محتوا باید تکمیل شود.
